# # # 1. Внутрішня та зовнішня функція приймає по одному аргументу, повернути добуток цих
# # # чисел. Завдання реалізувати з використанням замикання, у 2-ох варіантах, через
# # # звичайну, та анонімну функцію (як в аудиторії).
# # def dob(num_1):
# #     def func(num_2):
# #         return num_1 * num_2
# #     return func
# #
# #
# # x = dob(2)
# # print(x(3))
#
# # ---------- variant 2 ----------
# def dob(num_1):
#     return lambda num_2: num_1 *num_2
#
#
# x = dob(2)
# print(x(3))



# # 2. Реалізуйте функцію замикання, яка при виконанні даного коду як на фото 1, буде
# # видавати результат як на фото 2.
#
# # x = outer([])
# # x(7)
# # x(2)
# # print(x(1))
# #
# # [7, 2, 1]
#
# def func(lst=[]):
#     def func_2(num):
#         lst.append(num)
#         return lst
#     return func_2
#
# x = func()
# print(x(1))
# print(x(2))
# print(x(3))
# print(x(7))

# --------------------------------------------------------------------

# # 3. Зовнішня функція приймає в параметр text якусь стрічку, внутрішня,
# # анонімна, стрічку чисел введених через пробіл. Якщо text буде рівний 'list',
# # повернути список чисел, інакше кортеж чисел.
# def a(text, lst=[],a=tuple()):
#     def b(num):
#         if text == 'list':
#             lst.append(num)
#             for i in lst:
#                 lst_2 =[]
#                 lst_2 = i
#                 return lst_2
#         else:
#             a = tuple(num)
#             return a
#     return b
#
#
# txt = input('enter text:')
# numbers = input('enter numbers:').split()
#
# x = a(txt)
# print(x(numbers))





